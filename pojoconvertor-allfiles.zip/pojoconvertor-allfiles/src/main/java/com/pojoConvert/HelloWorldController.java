package com.pojoConvert;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;

import org.jsonschema2pojo.DefaultGenerationConfig;
import org.jsonschema2pojo.GenerationConfig;
import org.jsonschema2pojo.Jackson2Annotator;
import org.jsonschema2pojo.SchemaGenerator;
import org.jsonschema2pojo.SchemaMapper;
import org.jsonschema2pojo.SchemaStore;
import org.jsonschema2pojo.SourceType;
import org.jsonschema2pojo.rules.RuleFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.codemodel.JCodeModel;
@RestController
public class HelloWorldController 
{
@RequestMapping("/")
public String hello() 
{
return "Hello javaTpoint";
}

@RequestMapping("/validate")
public ResponseEntity validate(@RequestBody String s) {
	boolean value = true;
	System.out.println("s-"+s);
	//String s = "{\"age1\":\"23\",\"name1\":\"srinivas\",\"messages1\":[\"msg1\",\"msg2\",\"msg3\"]}";
	try {
		ObjectMapper mapper = new ObjectMapper();
		mapper.readTree(s);
	} catch(Exception ex) {
		value=false;
	}
	System.out.println("value-"+value);
	return ResponseEntity.ok().body(value);
}

@RequestMapping("/input")
public ResponseEntity convertpojo(@RequestBody String s) throws FileNotFoundException 
{
	String packageName="com.pojoConvert";
	Long time = System.currentTimeMillis();
	File outputPojoDirectory=new File("."+File.separator+"convertedPojo");
	File responseOutput=new File("."+File.separator+"convertedPojo/com/pojoConvert/Output"+time+".java");
	outputPojoDirectory.mkdirs();
	try {
		//String s = "{\"age1\":\"23\",\"name1\":\"srinivas\",\"messages1\":[\"msg1\",\"msg2\",\"msg3\"]}"; 
		new HelloWorldController().convert2JSON(s, outputPojoDirectory, packageName, "Output"+time);
	} catch (IOException e) {
		System.out.println("Encountered issue while converting to pojo: "+e.getMessage());
	}
	InputStreamResource resource = new InputStreamResource(new FileInputStream(responseOutput));

    return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=PojoConverted.java")
            .contentLength(responseOutput.length())
            .contentType(MediaType.APPLICATION_OCTET_STREAM)
            .body(resource);
}

public void convert2JSON(String inputJson, File outputPojoDirectory, String packageName, String className) throws IOException{
	JCodeModel codeModel = new JCodeModel();

	String source = inputJson;

	GenerationConfig config = new DefaultGenerationConfig() {
	@Override
	public boolean isGenerateBuilders() { // set config option by overriding method
	return true;
	}
	public SourceType getSourceType(){
        return SourceType.JSON;
    }
	};
	SchemaMapper mapper = new SchemaMapper(new RuleFactory(config, new Jackson2Annotator(config), new SchemaStore()), new SchemaGenerator());
	mapper.generate(codeModel, className, packageName, source);

	codeModel.build(outputPojoDirectory);
}
}
